package sobhanz.example;

import org.neo4j.driver.Record; // Make sure to specify the correct Record class
import org.neo4j.driver.Value;
import java.util.List;
import static org.neo4j.driver.Values.parameters;
import org.json.JSONObject;
import org.neo4j.driver.types.Node;

public class QueryHandler {
    private final Neo4jConnector neo4j;
    private final OllamaClient ollama;

    public QueryHandler(Neo4jConnector neo4j, OllamaClient ollama) {
        this.neo4j = neo4j;
        this.ollama = ollama;
    }

    public void processUserQuery(String input) {
        String extractionPrompt = """
                Analyze the user query and extract historical entities.
                Return ONLY a valid JSON object with NO extra text, explanations, or code.

                ### Example Output:
                {
                  "intent": "query_people",
                  "entities": {
                    "century": "5th",
                    "people": [
                      {
                        "name": "Plato",
                        "occupation": "philosopher"
                      }
                    ]
                  }
                }

                User input: "%s"
                """.formatted(input);

        String response = ollama.generate("llama3.2", extractionPrompt);

        System.out.println("\n[Ollama Raw Response]: " + response);

        // ✅ مرحله‌ی پاکسازی و تصحیح JSON
        response = cleanJsonString(response);

        if (!response.trim().startsWith("{")) {
            System.out.println("[Error] Ollama returned non-JSON output. Ignoring response.");
            return;
        }

        try {
            JSONObject extractedData = new JSONObject(response);
            System.out.println("\n[Extracted JSON Data]: " + extractedData.toString(2));

            if (extractedData.isNull("intent")) {
                System.out.println("[Error] No intent detected in response.");
                return;
            }

            switch (extractedData.getString("intent")) {
                case "query_person":
                    String personName = getSafeString(extractedData.getJSONObject("entities"), "person");
                    getPersonInfo(personName);
                    break;
                case "query_people":
                    String century = getSafeString(extractedData.getJSONObject("entities"), "century");
                    getPeopleByCentury(century);
                    break;
                case "query_by_occupation":
                    String occupation = getSafeString(extractedData.getJSONObject("entities"), "occupation");
                    getPeopleByOccupation(occupation);
                    break;
                case "query_by_city":
                    String city = getSafeString(extractedData.getJSONObject("entities"), "city");
                    getPeopleByCity(city);
                    break;
                default:
                    System.out.println("[Error] I didn't understand your request.");
            }
        } catch (Exception e) {
            System.out.println("[Error] JSON Parsing failed: " + e.getMessage());
            System.out.println("[Debug] Ollama Response: " + response);
        }
    }

    /**
     * ✅ متدی برای تصحیح و پاکسازی JSON ناسازگار
     */
    private String cleanJsonString(String json) {
        // حذف فاصله‌های اضافی در کلیدهای JSON
        json = json.replaceAll("\\s+\"", "\""); // حذف فاصله‌های قبل از نام کلیدها
        json = json.replaceAll("\"\\s+:", "\":"); // حذف فاصله‌های بعد از نام کلیدها

        // حذف فاصله‌های اضافی بین مقدارها
        json = json.replaceAll(":\\s+", ":");

        return json;
    }

    private String getSafeString(JSONObject json, String key) {
        if (!json.has(key) || json.isNull(key)) {
            return "Unknown";
        }

        Object value = json.get(key);
        if (value instanceof Number) {
            return String.format("%.2f", ((Number) value).doubleValue());
        }

        return value.toString();
    }

    private void printIfExists(String label, String value) {
        if (!value.equals("Unknown")) {
            System.out.println(" " + label + ": " + value);
        }
    }

    public void getPersonInfo(String name) {
        String query = "MATCH (p:Person {full_name: $name}) RETURN p";
        List<Record> results = neo4j.runReadQuery(query, parameters("name", name));

        if (!results.isEmpty()) {
            System.out.println("\n=======  Person Information  =======");
            for (Record record : results) {
                Node personNode = record.get("p").asNode();

                printIfExists("Full Name", getSafeString(personNode, "full_name"));
                printIfExists("Gender", getSafeString(personNode, "sex"));
                printIfExists("Birth Year", getSafeString(personNode, "birth_year"));
                printIfExists("City", getSafeString(personNode, "city"));
                printIfExists("Country", getSafeString(personNode, "country"));
                printIfExists("Continent", getSafeString(personNode, "continent"));
                printIfExists("Popularity Index", getSafeString(personNode, "historical_popularity_index"));
                printIfExists("Average Views", getSafeString(personNode, "average_views"));
                printIfExists("Total Page Views", getSafeString(personNode, "page_views"));

                String latitude = getSafeString(personNode, "latitude");
                String longitude = getSafeString(personNode, "longitude");
                if (!latitude.equals("Unknown") && !longitude.equals("Unknown")) {
                    System.out.println("🌍 Location (Lat, Long): " + latitude + ", " + longitude);
                }
            }
            System.out.println("=========================================");
        } else {
            System.out.println(" [Error] No person found with name: " + name);
        }
    }

    public void getPeopleByCentury(String century) {
        String query = "MATCH (p:Person)-[:BORN_IN]->(:Century {century: $century}) RETURN p.full_name";
        List<Record> results = neo4j.runReadQuery(query, parameters("century", century));

        if (results.isEmpty()) {
            System.out.println("\n No historical data found for the  " + century + " century.");
        } else {
            System.out.println("\n People from Century " + century + ":");
            results.forEach(record -> System.out.println("🔹 " + record.get("p.full_name").asString()));
        }
    }

    public void getPeopleByOccupation(String occupation) {
        String query = "MATCH (p:Person)-[:WORKS_AS]->(:Occupation {name: $occupation}) RETURN p.full_name";
        List<Record> results = neo4j.runReadQuery(query, parameters("occupation", occupation));

        if (results.isEmpty()) {
            System.out.println("\n No historical figures found with occupation: " + occupation);
        } else {
            System.out.println("\n People with Occupation: " + occupation);
            results.forEach(record -> System.out.println("🔹 " + record.get("p.full_name").asString()));
        }
    }

    public void getPeopleByCity(String city) {
        String query = "MATCH (p:Person)-[:BORN_IN_CITY]->(:City {name: $city}) RETURN p.full_name";
        List<Record> results = neo4j.runReadQuery(query, parameters("city", city));

        if (results.isEmpty()) {
            System.out.println("\n No historical figures found from city: " + city);
        } else {
            System.out.println("\n People from City " + city + ":");
            results.forEach(record -> System.out.println("🔹 " + record.get("p.full_name").asString()));
        }
    }

    private String getSafeString(Node node, String key) {
        if (!node.containsKey(key))
            return "Unknown";

        Value value = node.get(key);
        if (value.isNull())
            return "Unknown";

        // چک کردن نوع مقدار و تبدیل صحیح
        if (value.type().name().equals("INTEGER") || value.type().name().equals("FLOAT")) {
            return String.valueOf(value.asNumber());
        }

        // اگر مقدار رشته‌ای بود
        String text = value.asString().trim();
        return text.isEmpty() ? "Unknown" : text;
    }

}
